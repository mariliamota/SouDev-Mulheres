CREATE DATABASE db_digital_store;
USE db_digital_store;